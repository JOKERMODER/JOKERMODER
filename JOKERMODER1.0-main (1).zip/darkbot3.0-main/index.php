[ 'https://www.java.com/pt-BR/' ]
echo = database.java
fi
